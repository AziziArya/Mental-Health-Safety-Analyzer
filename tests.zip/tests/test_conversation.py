from src.pipeline.analyzer import MentalHealthAnalyzer

from src.conversation_analyzer.conversation import ConversationAnalyzer

from src.emotion_evolution.evolution import EmotionEvolutionAnalyzer

from src.conversation_pattern.pattern import ConversationPatternAnalyzer

from src.context_memory.memory import ConversationMemory

from src.context_fusion.fusion import ContextFusionEngine



# ============================
# Main Analyzer
# ============================

analyzer = MentalHealthAnalyzer()



# ============================
# Conversation Modules
# ============================

emotion_evolution = EmotionEvolutionAnalyzer()


pattern_analyzer = ConversationPatternAnalyzer()


memory = ConversationMemory()


context_fusion = ContextFusionEngine()



# ============================
# Conversation Analyzer
# ============================

conversation = ConversationAnalyzer(

    analyzer,

    emotion_evolution=emotion_evolution,

    pattern_analyzer=pattern_analyzer,

    memory=memory,

    context_fusion=context_fusion

)



# ============================
# Test Conversation
# ============================

messages = [

    "I feel a little sad today.",

    "Nobody understands me and I feel alone.",

    "I don't want to live anymore."

]



# ============================
# Run Analysis
# ============================

result = conversation.analyze_conversation(
    messages
)



print("\n=== CONVERSATION ANALYSIS ===")

print(result)



# ============================
# Optional Checks
# ============================

print("\n=== CHECKS ===")


print(
    "Risk Trend:",
    result["risk_trend"]
)


print(
    "Overall Risk:",
    result["overall_risk"]
)



if "emotion_evolution" in result:

    print(
        "Emotion Evolution:",
        result["emotion_evolution"]
    )



if "conversation_patterns" in result:

    print(
        "Conversation Patterns:",
        result["conversation_patterns"]
    )



if "memory_context" in result:

    print(
        "Memory Context:",
        result["memory_context"]
    )



if "context_fusion" in result:

    print(
        "Context Fusion:",
        result["context_fusion"]
    )