from fastapi.testclient import TestClient

from src.api.main import app


client = TestClient(app)



def print_section(title):

    print("\n" + "=" * 50)

    print(title)

    print("=" * 50)





def test_home():

    response = client.get("/")


    assert response.status_code == 200


    data = response.json()


    print_section(
        "HOME"
    )

    print(data)


    assert "message" in data





def test_health():

    response = client.get("/health")


    assert response.status_code == 200


    data = response.json()


    print_section(
        "HEALTH"
    )

    print(data)


    assert data["status"] == "healthy"






def test_single_message_pipeline():

    payload = {

        "text":
        "I feel hopeless and nobody understands me."

    }



    response = client.post(

        "/analyze",

        json=payload

    )


    assert response.status_code == 200



    data = response.json()



    print_section(
        "SINGLE MESSAGE PIPELINE"
    )


    print(data)



    assert "risk_assessment" in data

    assert "recommended_action" in data

    assert "safety_note" in data







def test_conversation_pipeline():


    payload = {


        "messages": [

            "I feel sad today.",


            "Nobody understands me and I feel alone.",


            "I don't want to live anymore."

        ]

    }





    response = client.post(

        "/analyze-conversation",

        json=payload

    )



    assert response.status_code == 200



    data = response.json()



    print_section(

        "CONVERSATION PIPELINE"

    )


    print(data)





    # Core pipeline checks

    assert "conversation_id" in data

    assert "message_count" in data

    assert "timeline" in data


    assert "risk_trend" in data

    assert "overall_risk" in data



    # Emotion analysis

    assert "emotion_evolution" in data



    # Conversation patterns

    assert "conversation_patterns" in data



    # Memory

    assert "memory_context" in data



    # Context fusion

    assert "context_fusion" in data



    # Decision engine

    assert "decision" in data



    decision = data["decision"]



    assert "final_risk_score" in decision

    assert "final_risk_level" in decision

    assert "recommended_actions" in decision



    assert decision["final_risk_level"] in [

        "Safe",

        "Mild Concern",

        "Moderate Risk",

        "High Risk",

        "Critical Emergency"

    ]





    # Explainability

    assert "explainability" in data


    explainability = data["explainability"]



    assert "summary" in explainability

    assert "key_factors" in explainability





    # Response generator

    assert "safety_response" in data



    safety_response = data["safety_response"]



    assert "message" in safety_response

    assert "response_type" in safety_response

    assert "priority" in safety_response





    print_section(

        "DECISION"

    )


    print(decision)



    print_section(

        "EXPLAINABILITY"

    )


    print(explainability)



    print_section(

        "SAFETY RESPONSE"

    )


    print(safety_response)







if __name__ == "__main__":


    test_home()

    test_health()

    test_single_message_pipeline()

    test_conversation_pipeline()



    print(

        "\nFULL PIPELINE TEST PASSED"

    )