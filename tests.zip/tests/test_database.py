from src.database.database import engine, Base


print("Creating database...")


Base.metadata.create_all(
    bind=engine
)


print(
    "DATABASE CREATED"
)